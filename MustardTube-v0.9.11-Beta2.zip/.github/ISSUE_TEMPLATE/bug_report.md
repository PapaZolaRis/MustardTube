---
name: Bug report
about: Report a reproducible problem on an H700 device
labels: bug
---

**Device:** RG35XX Plus / RG35XX SP

**muOS firmware:** 2606.0 Andromeda (or specify)

**MustardTube version:** v0.9.11 Beta 2 (or specify)

**Tab / action:**

**Steps to reproduce:**

1.
2.
3.

**Expected result:**

**Actual result:**

**Video quality or radio station, if relevant:**

**Additional information / screenshot / redacted log:**

> Please REMOVE passwords, tokens, signed media URLs, user history and personal
> information from attached logs.
