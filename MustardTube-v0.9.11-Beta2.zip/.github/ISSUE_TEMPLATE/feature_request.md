---
name: Feature request
about: Suggest a lightweight feature for MustardTube
labels: enhancement
---

**What problem would this solve?**

**Proposed feature:**

**How would this remain lightweight on H700 / muOS Andromeda?**
